<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep Cargo Pilot's frontend feature components under `src/components/cargo` and sample records under `src/lib/cargo-data.ts`; shared records keep overview and focused views consistent.
- Keep navigation between operational workspace views client-side on the dashboard route; these views share filters and session-only state without requiring backend services.
