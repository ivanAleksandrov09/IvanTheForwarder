# Cargo Pilot
- [x] Establish premium light/dark dashboard design system.
- [x] Build overview KPIs, fleet GPS list, operational alerts, client risk table/detail, mailbox and draft approval queue.
- [x] Verify interactive workflows and presentation.