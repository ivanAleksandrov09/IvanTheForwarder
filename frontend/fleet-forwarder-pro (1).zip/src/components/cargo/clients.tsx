import { useState } from 'react';
import { ShieldCheck, ChevronRight, ArrowDown, ArrowUpRight, Mail, Search, Pencil, Trash2 } from 'lucide-react';
import { clients as initialClients, type Client } from '@/lib/cargo-data';
import { PanelHeader, RiskBadge } from './common';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { toast } from 'sonner';

const RISK_LEVELS = ['High', 'Medium', 'Low'];

export function ClientRiskTable({ expanded = false, onExpand, onEmail }: { expanded?: boolean | undefined; onExpand?: (() => void) | undefined; onEmail?: (() => void) | undefined }) {
  const [clientList, setClientList] = useState<Client[]>(initialClients);
  const [selected, setSelected] = useState<Client | null>(null);
  const [editing, setEditing] = useState<Client | null>(null);
  const [deleting, setDeleting] = useState<Client | null>(null);
  const [query, setQuery] = useState('');
  const [risk, setRisk] = useState('All risks');
  const [descending, setDescending] = useState(true);

  const filtered = clientList
    .filter(c => c.name.toLowerCase().includes(query.toLowerCase()) && (risk === 'All risks' || c.risk === risk))
    .sort((a, b) => descending ? b.score - a.score : a.score - b.score);

  const saveClient = (updated: Client) => {
    setClientList(list => list.map(c => (c.id === updated.id ? updated : c)));
    setEditing(null);
    toast.success(`${updated.name} updated`);
  };

  const deleteClient = (client: Client) => {
    setClientList(list => list.filter(c => c.id !== client.id));
    setDeleting(null);
    if (selected?.id === client.id) setSelected(null);
    toast.success(`${client.name} removed`);
  };

  return (
    <>
      <section className="panel table-panel">
        <PanelHeader title="Client risk overview" icon={<ShieldCheck />} count={clientList.length} action={expanded ? undefined : 'View all clients'} onAction={onExpand} />
        {expanded && (
          <div className="flex gap-3 p-4 border-b border-border">
            <div className="flex items-center gap-2">
              <Search size={14} className="text-muted-foreground" />
              <input aria-label="Search clients" placeholder="Search clients…" className="filter-input" value={query} onChange={e => setQuery(e.target.value)} />
            </div>
            <select className="filter-select" aria-label="Filter client risk" value={risk} onChange={e => setRisk(e.target.value)}>
              {['All risks', ...RISK_LEVELS].map(r => <option key={r}>{r}</option>)}
            </select>
          </div>
        )}
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Client</th>
                <th>
                  <Button variant="ghost" className="h-auto p-0 text-[10px] text-muted-foreground" onClick={() => setDescending(!descending)}>
                    Risk score<ArrowDown size={10} className={descending ? '' : 'rotate-180'} />
                  </Button>
                </th>
                <th>Risk level</th>
                <th>Outstanding</th>
                <th>Recent incident</th>
                <th className="text-right">Actions</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id} tabIndex={0} aria-label={`View ${c.name}`} onClick={() => setSelected(c)} onKeyDown={e => { if (e.key === 'Enter') setSelected(c); }}>
                  <td>
                    <div className="client-name">
                      <div className="client-avatar">{c.initials}</div>
                      <div><strong>{c.name}</strong><small>{c.country}</small></div>
                    </div>
                  </td>
                  <td>
                    <div className="risk-score">
                      <span>{c.score}<span className="subtle text-[9px]"> / 100</span></span>
                      <div className="risk-meter"><div className={`risk-fill ${c.risk.toLowerCase()} score-${c.score}`} /></div>
                    </div>
                  </td>
                  <td><RiskBadge level={c.risk} /></td>
                  <td className="font-medium">{c.outstanding}</td>
                  <td className={c.risk === 'Low' ? 'subtle' : ''}>{c.incident}</td>
                  <td className="text-right whitespace-nowrap">
                    <Button
                      variant="ghost" size="icon" className="h-7 w-7" aria-label={`Edit ${c.name}`}
                      onClick={e => { e.stopPropagation(); setEditing(c); }}
                    >
                      <Pencil size={13} />
                    </Button>
                    <Button
                      variant="ghost" size="icon" className="h-7 w-7 text-destructive" aria-label={`Delete ${c.name}`}
                      onClick={e => { e.stopPropagation(); setDeleting(c); }}
                    >
                      <Trash2 size={13} />
                    </Button>
                  </td>
                  <td><ChevronRight className="row-arrow" /></td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && <div className="empty-state">No clients match your search.</div>}
        </div>
        <div className="panel-footer">
          <span>{expanded ? `${filtered.length} sample clients` : `Showing ${Math.min(filtered.length, 5)} of ${clientList.length} clients`}<span className="mx-2">·</span>Scores updated 5 min ago</span>
          <span className="flex items-center gap-1"><span className="status-dot" />Monitoring active</span>
        </div>
      </section>
      <ClientDetail client={selected} onClose={() => setSelected(null)} onEmail={onEmail} onEdit={c => { setSelected(null); setEditing(c); }} onDelete={c => { setSelected(null); setDeleting(c); }} />
      <ClientEditDialog client={editing} onClose={() => setEditing(null)} onSave={saveClient} />
      <ClientDeleteDialog client={deleting} onClose={() => setDeleting(null)} onConfirm={deleteClient} />
    </>
  );
}

export function ClientDetail({ client, onClose, onEmail, onEdit, onDelete }: { client: Client | null; onClose: () => void; onEmail?: (() => void) | undefined; onEdit?: ((c: Client) => void) | undefined; onDelete?: ((c: Client) => void) | undefined }) {
  return (
    <Dialog open={!!client} onOpenChange={open => { if (!open) onClose(); }}>
      <DialogContent>
        <DialogTitle>{client?.name}</DialogTitle>
        <DialogDescription>{client?.country} · {client?.id}</DialogDescription>
        {client && (
          <>
            <div className="detail-stat-grid">
              <div><span className="subtle small">Risk score</span><strong>{client.score}<span className="subtle text-xs"> / 100</span></strong></div>
              <div><span className="subtle small">Outstanding</span><strong>{client.outstanding}</strong></div>
              <div><span className="subtle small">Active shipments</span><strong>{client.shipments}</strong></div>
            </div>
            <div className="detail-row"><span className="subtle">Risk level</span><RiskBadge level={client.risk} /></div>
            <div className="detail-row"><span className="subtle">Account contact</span>{client.contact}</div>
            <div className="detail-row"><span className="subtle">Recent incident</span>{client.incident}</div>
            <div className="detail-row"><span className="subtle">Last activity</span>{client.date}</div>
            <div className="border-t border-border pt-4">
              <div className="flex items-center gap-2 font-medium"><ShieldCheck size={15} />Risk assessment</div>
              <p className="detail-body text-xs mt-2">
                {client.risk === 'High'
                  ? 'Payment and documentation issues require attention. Review outstanding invoices and resolve operational incidents before extending additional credit.'
                  : client.risk === 'Medium'
                    ? 'Moderate operational exposure. Follow up on shipping documents and monitor free-time deadlines to avoid demurrage.'
                    : 'Payment history and operational performance are within acceptable thresholds. No immediate action is required.'}
              </p>
            </div>
            <div className="flex items-center justify-between gap-2">
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => onEdit?.(client)}><Pencil size={13} />Edit</Button>
                <Button variant="outline" size="sm" className="text-destructive" onClick={() => onDelete?.(client)}><Trash2 size={13} />Delete</Button>
              </div>
              <Button size="sm" onClick={() => { onClose(); onEmail?.(); }}><Mail />Open mailbox<ArrowUpRight /></Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function ClientEditDialog({ client, onClose, onSave }: { client: Client | null; onClose: () => void; onSave: (c: Client) => void }) {
  const [form, setForm] = useState<Client | null>(null);
  const active = form && form.id === client?.id ? form : client;
  if (active !== form) setForm(active);

  const update = <K extends keyof Client>(key: K, value: Client[K]) => setForm(f => (f ? { ...f, [key]: value } : f));

  return (
    <Dialog open={!!client} onOpenChange={open => { if (!open) { setForm(null); onClose(); } }}>
      <DialogContent>
        <DialogTitle>Edit client</DialogTitle>
        <DialogDescription>{client?.id} · Changes apply to this session only</DialogDescription>
        {active && (
          <>
            <div className="grid gap-3">
              <label className="grid gap-1 text-xs">
                <span className="subtle">Company name</span>
                <input className="filter-input w-full" value={active.name} onChange={e => update('name', e.target.value)} />
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className="grid gap-1 text-xs">
                  <span className="subtle">Country</span>
                  <input className="filter-input w-full" value={active.country} onChange={e => update('country', e.target.value)} />
                </label>
                <label className="grid gap-1 text-xs">
                  <span className="subtle">Account contact</span>
                  <input className="filter-input w-full" value={active.contact} onChange={e => update('contact', e.target.value)} />
                </label>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <label className="grid gap-1 text-xs">
                  <span className="subtle">Risk score (0–100)</span>
                  <input className="filter-input w-full" type="number" min={0} max={100} value={active.score} onChange={e => update('score', Math.max(0, Math.min(100, Number(e.target.value) || 0)))} />
                </label>
                <label className="grid gap-1 text-xs">
                  <span className="subtle">Risk level</span>
                  <select className="filter-select w-full" value={active.risk} onChange={e => update('risk', e.target.value)}>
                    {RISK_LEVELS.map(r => <option key={r}>{r}</option>)}
                  </select>
                </label>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <label className="grid gap-1 text-xs">
                  <span className="subtle">Outstanding</span>
                  <input className="filter-input w-full" value={active.outstanding} onChange={e => update('outstanding', e.target.value)} />
                </label>
                <label className="grid gap-1 text-xs">
                  <span className="subtle">Active shipments</span>
                  <input className="filter-input w-full" type="number" min={0} value={active.shipments} onChange={e => update('shipments', Math.max(0, Number(e.target.value) || 0))} />
                </label>
              </div>
              <label className="grid gap-1 text-xs">
                <span className="subtle">Recent incident</span>
                <input className="filter-input w-full" value={active.incident} onChange={e => update('incident', e.target.value)} />
              </label>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => { setForm(null); onClose(); }}>Cancel</Button>
              <Button size="sm" onClick={() => { if (form) { onSave(form); setForm(null); } }}>Save changes</Button>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function ClientDeleteDialog({ client, onClose, onConfirm }: { client: Client | null; onClose: () => void; onConfirm: (c: Client) => void }) {
  return (
    <Dialog open={!!client} onOpenChange={open => { if (!open) onClose(); }}>
      <DialogContent>
        <DialogTitle>Remove {client?.name}?</DialogTitle>
        <DialogDescription>
          This removes the client from the risk overview for this session. Outstanding balance: {client?.outstanding}.
        </DialogDescription>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" variant="destructive" onClick={() => client && onConfirm(client)}><Trash2 size={13} />Remove client</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
